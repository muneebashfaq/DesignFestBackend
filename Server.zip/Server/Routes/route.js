const express = require('express')
const router = express.Router()

//create Middleware for Authentication
const authenticateToken = require('./authentication.js'); 

const { CreateUser, GetUser, DeleteUser, UpdateUser, GetUserByEmail } = require('../Views/User.views')
const { CreateBooking,UpdateBooking ,GetAllBooking,DeleteBooking} = require('../Views/Account.views')
const { body, validationResult } = require('express-validator');

var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');

const SECRET_KEY = "MUNEEBMUGHAL"
const session = require('express-session')
const cookieParser = require('cookie-parser')

router.use(cookieParser());
router.use(session({
    resave: true,
    saveUninitialized: true,
    secret: "secret"
}))

//this is for authentication
//create/signup the user
router.post('/createusers', async (req, res) => {
    try {
        var User = []
        const { First_name, Last_name, Email, Gender, Password, Type, Hex, TwoFAEnabled } = req.query
        var User = await GetUserByEmail(Email)
        if (User) {
            res.status(500).send("User Already Exist")
        } else {
            //this is use to encrypt the password
            var salt = bcrypt.genSaltSync(10);
            var hashPassword = bcrypt.hashSync(Password, salt);
            //Type 2 for the user and type 1 for the admin
            const users = await CreateUser(First_name, Last_name, Email, Gender, hashPassword, Type, Hex, TwoFAEnabled)
            const data = {
                user: {
                    id: users.id
                }
            }
            //this is use to create the auth token
            const authtoken = jwt.sign(data, SECRET_KEY)
            res.status(200).send({ authtoken, First_name })
        }
    } catch (err) {
        res.status(400).send("User Not Created:" + err)
    }
})
//login user
router.post('/login', async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }
        try {
            const { Email, Password } = req.query
            const User = await GetUserByEmail(Email)
            const checkuser = await bcrypt.compare(Password, User.Password)

            if (checkuser) {
                const data = {
                    user: {
                        id: User.id
                    }
                }
                const authtoken = jwt.sign(data, SECRET_KEY)
                // req.session.user = User;
                // req.session.save()
                res.status(200).send({ authtoken, User })

            } else {
                res.status(500).send("Please Login With Correct Credatials")
            }

        } catch (err) {
            res.status(400).send("Some Error Occurs" + err)
        }
    })
//to logout user
router.get('/logout', async (req, res) => {
    req.session.destroy();
    res.send("User Logout")
})
//to get all the users
router.get('/users', async (req, res) => {
    const data = await GetUser()
    res.send(data)
})
//to update the user
router.post('/update', async (req, res) => {
    // const { id, First_name, Last_name, Email, Gender } = req.query
    const { id, First_name, Last_name, Email, Gender } = req.query
    try {
        if (id !== '' && id !== undefined && First_name !== '' && First_name !== undefined &&
            Last_name !== '' && Last_name !== undefined && Email !== '' && Email !== undefined && Gender !== '' && Gender !== undefined) {
            const data = await UpdateUser(id, First_name, Last_name, Email, Gender)
            res.send(data)
        } else {
            res.status(411).send("Input Field Is Missing")
        }
    }
    catch (err) {
        res.status(400).send("Record Not Updated Please Try Again " + err)
    }
})
//to delete the user
router.get('/delete', async (req, res) => {
    const { id } = req.query
    try {
        const data = await DeleteUser(id)
        res.send(data)
    }
    catch (err) {
        res.status(404).send("Record Not Found " + err)
    }
})


//to create Booking
router.post('/createBooking',authenticateToken, async (req, res) => {
    const { owner_id, account_name, Email, TicketType } = req.query
    try {
        const account = await CreateBooking(owner_id, account_name, Email, TicketType)
        res.status(200).send(true)
    } catch (err) {
        res.status(400).send("Booking Not Created:" + err)
    }

})

//to get Booking 

router.get('/getBookings',authenticateToken, async (req, res) => {
    try {
        const data = await GetAllBooking()
        res.send(data)
    }
    catch (err) {
        res.status(400).send("There is some error:" + err)
    }
})


//for delete an Booking
router.get('/deleteBooking',authenticateToken, async (req, res) => {
    const { id } = req.query
    try {
        const data = await DeleteBooking(id)
        res.send(data)
    }
    catch (err) {
        res.status(404).send("Record Not Found " + err)
    }
})

//for updateBooking
router.post('/updateBooking',authenticateToken, async (req, res) => {
    const { id, AccountName, Email, TicketType } = req.query
    try {
        if (id !== '' && id !== undefined && AccountName !== '' && AccountName !== undefined &&
            Email !== '' && Email !== undefined && TicketType !== '' && TicketType !== undefined) {
            const data = await UpdateBooking(id, AccountName, Email, TicketType)
            res.send(data)
        } else {
            res.status(411).send("Input Field Is Missing")
        }
    }
    catch (err) {
        res.status(400).send("Record Not Updated Please Try Again " + err)
    }
})



module.exports = router