const { BookingModel} = require('../models/booking.model')

const CreateBooking = async (Owner_ID, Name, Email, TicketType) => {
    const resp = await BookingModel.create({
        ID: `${Owner_ID}`,
        Name: `${Name}`,
        Email: `${Email}`,
        TicketType: `${TicketType}`,

    })
    return resp;
}

const UpdateBooking = async (id, AccountName, Email, TicketType) => {
    const resp = await BookingModel.updateOne({
        _id: id
    }, { $set: { Name: AccountName, Email: Email, TicketType: TicketType } })
    return resp.acknowledged
}


const GetAllBooking= async () => {
    const resp_data = await BookingModel.find()
    return resp_data;
}


const DeleteBooking = async (Id) => {
    const data = await BookingModel.findOne({ _id: Id })
    const resp = await BookingModel.deleteOne({
        _id: Id
    })
    return data

}



module.exports = {CreateBooking,UpdateBooking ,GetAllBooking,DeleteBooking } 