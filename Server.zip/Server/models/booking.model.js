const mongoose = require('mongoose')

var BookingSchema = new mongoose.Schema({
    ID: { type: mongoose.Schema.Types.ObjectId, required: true },
    Name: { type: String, required: true },
    Email: { type: String, required: true },
    TicketType: { type: String, required: true },  
})



var BookingModel = mongoose.model("Booking", BookingSchema)



module.exports = {BookingModel} 